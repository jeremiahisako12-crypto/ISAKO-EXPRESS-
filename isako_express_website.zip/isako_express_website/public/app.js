const $ = (s) => document.querySelector(s);
$("#year").textContent = new Date().getFullYear();
$("#menuToggle").addEventListener("click", () => $("#mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("#mainNav").classList.remove("open")));

document.querySelectorAll("[data-service]").forEach(link => link.addEventListener("click", () => {
  const field = $("#serviceSelect"); if (field) field.value = link.dataset.service;
}));
document.querySelectorAll("[data-destination]").forEach(link => link.addEventListener("click", () => {
  const field = $("#destinationSelect"); if (field) field.value = link.dataset.destination;
}));

function showMessage(el, message, good = false) {
  el.textContent = message;
  el.style.color = good ? "#218653" : "#c44b2d";
}
$("#quoteForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const result = $("#quoteResult");
  const data = Object.fromEntries(new FormData(e.currentTarget).entries());
  const button = e.currentTarget.querySelector("button[type=submit]");
  button.disabled = true; button.textContent = "Envoi en cours…";
  try {
    const response = await fetch("/api/inquiries", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data) });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Impossible d'envoyer la demande.");
    showMessage(result, `Demande enregistrée (#${payload.id}). Merci ! Notre équipe vous recontactera.`, true);
    e.currentTarget.reset();
  } catch (err) {
    showMessage(result, `${err.message} Vous pouvez aussi nous contacter sur WhatsApp au +243 894 226 845.`);
  } finally { button.disabled = false; button.innerHTML = 'Envoyer ma demande <span>↗</span>'; }
});

$("#trackingForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const result = $("#trackingResult");
  const code = $("#trackingCode").value.trim().toUpperCase();
  result.textContent = "Recherche du colis…"; result.style.color = "#66738a";
  try {
    const response = await fetch("/api/track/" + encodeURIComponent(code));
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Colis introuvable.");
    const s = payload.shipment;
    result.innerHTML = `<div class="result-card"><strong>${escapeHTML(s.tracking_code)}</strong><br>Statut : <strong>${escapeHTML(s.status)}</strong><br>Destination : ${escapeHTML(s.destination)}<br>${s.description ? "Marchandise : " + escapeHTML(s.description) + "<br>" : ""}${s.notes ? "Information : " + escapeHTML(s.notes) + "<br>" : ""}<small>Dernière mise à jour : ${escapeHTML(s.updated_at)}</small></div>`;
    result.style.color = "#218653";
  } catch (err) { showMessage(result, err.message); }
});
function escapeHTML(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
