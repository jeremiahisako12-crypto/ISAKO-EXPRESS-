const q = s => document.querySelector(s);
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function msg(el, text, good=false){el.textContent=text;el.style.color=good?"#218653":"#c44b2d";}
async function api(url, options={}) {
  const r=await fetch(url,{...options,headers:{...(options.body instanceof FormData?{}:{"Content-Type":"application/json"}),...(options.headers||{})}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(d.error||"Erreur de requête");
  return d;
}
async function checkSession(){try{await api("/api/admin/me");q("#loginPanel").classList.add("hidden");q("#dashboard").classList.remove("hidden");await loadDashboard();}catch{q("#loginPanel").classList.remove("hidden");q("#dashboard").classList.add("hidden");}}
q("#loginForm").addEventListener("submit",async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget));try{await api("/api/admin/login",{method:"POST",body:JSON.stringify(data)});msg(q("#loginMessage"),"Connexion réussie.",true);await checkSession();}catch(err){msg(q("#loginMessage"),err.message);}});
q("#logoutBtn").addEventListener("click",async()=>{try{await api("/api/admin/logout",{method:"POST"});}finally{location.reload();}});
q("#shipmentForm").addEventListener("submit",async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget));try{const d=await api("/api/admin/shipments",{method:"POST",body:JSON.stringify(data)});msg(q("#shipmentMessage"),"Colis créé. Code à transmettre au client : "+d.tracking_code,true);e.currentTarget.reset();await loadDashboard();}catch(err){msg(q("#shipmentMessage"),err.message);}});
q("#logoForm").addEventListener("submit",async e=>{e.preventDefault();const fd=new FormData(e.currentTarget);try{const d=await api("/api/admin/logo",{method:"POST",body:fd});q("#logoPreview").src=d.logo+"?t="+Date.now();q("#logoPreview").classList.remove("hidden");msg(q("#logoMessage"),"Logo importé. Il reste à l’activer dans l’identité visuelle du site.",true);}catch(err){msg(q("#logoMessage"),err.message);}});
async function loadDashboard(){
  const d=await api("/api/admin/dashboard");
  q("#countInquiries").textContent=d.counts.inquiries;q("#countShipments").textContent=d.counts.shipments;q("#countActive").textContent=d.counts.activeShipments;
  q("#inquiriesTable").innerHTML=d.inquiries.length?d.inquiries.map(i=>`<tr><td>${i.id}</td><td><strong>${esc(i.name)}</strong><br>${esc(i.details)}</td><td>${esc(i.service)}<br><strong>${esc(i.destination)}</strong></td><td>${esc(i.phone)}<br>${esc(i.email)}</td><td><select data-inquiry="${i.id}">${["Nouveau","En cours","Traité","Archivé"].map(s=>`<option ${s===i.status?"selected":""}>${s}</option>`).join("")}</select></td><td>${esc(i.created_at)}</td></tr>`).join(""):`<tr><td colspan="6">Aucune demande pour le moment.</td></tr>`;
  q("#shipmentsTable").innerHTML=d.shipments.length?d.shipments.map(s=>`<tr><td><strong>${esc(s.tracking_code)}</strong></td><td>${esc(s.customer_name)}<br>${esc(s.customer_phone)}</td><td>${esc(s.destination)}</td><td><select data-status="${s.id}">${["Reçu en Chine","En préparation","En transit","Arrivé en RDC","En livraison","Livré","Annulé"].map(x=>`<option ${x===s.status?"selected":""}>${x}</option>`).join("")}</select></td><td><input data-notes="${s.id}" value="${esc(s.notes)}" maxlength="1000" style="width:160px;padding:7px;border:1px solid #e5e9ef;border-radius:5px"></td><td><button class="button button-primary" data-save="${s.id}" style="padding:8px 10px;font-size:10px">Enregistrer</button><br><small>${esc(s.updated_at)}</small></td></tr>`).join(""):`<tr><td colspan="6">Aucun colis enregistré pour le moment.</td></tr>`;
  document.querySelectorAll("[data-inquiry]").forEach(el=>el.addEventListener("change",async()=>{try{await api("/api/admin/inquiries/"+el.dataset.inquiry,{method:"PATCH",body:JSON.stringify({status:el.value})});}catch(err){alert(err.message);}}));
  document.querySelectorAll("[data-save]").forEach(el=>el.addEventListener("click",async()=>{const id=el.dataset.save;try{await api("/api/admin/shipments/"+id,{method:"PATCH",body:JSON.stringify({status:q(`[data-status="${id}"]`).value,notes:q(`[data-notes="${id}"]`).value})});el.textContent="Enregistré ✓";setTimeout(()=>loadDashboard(),700);}catch(err){alert(err.message);}}));
}
checkSession();
