require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "public", "uploads");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) {
  console.warn("WARNING: Set SESSION_SECRET to a random value of at least 24 characters in .env");
}
if (process.env.NODE_ENV === "production" && (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 14)) {
  throw new Error("Set ADMIN_PASSWORD to a strong password (at least 14 characters) before production.");
}

const db = new Database(path.join(DATA_DIR, "isako.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS inquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT,
    service TEXT NOT NULL, destination TEXT NOT NULL,
    details TEXT, status TEXT NOT NULL DEFAULT 'Nouveau',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_code TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    customer_phone TEXT,
    description TEXT,
    origin TEXT NOT NULL DEFAULT 'Shanghai, Chine',
    destination TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Reçu en Chine',
    notes TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const adminEmail = (process.env.ADMIN_EMAIL || "admin@isakoexpress.com").trim().toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD;
if (adminPassword && !db.prepare("SELECT id FROM admins WHERE email = ?").get(adminEmail)) {
  db.prepare("INSERT INTO admins (email, password_hash) VALUES (?, ?)").run(adminEmail, bcrypt.hashSync(adminPassword, 12));
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));
app.use(session({
  name: "isako.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-session-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 4
  }
}));
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const inquiryLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => cb(null, "company-logo" + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"].includes(file.mimetype);
    cb(ok ? null : new Error("Format autorisé : PNG, JPG, WEBP ou SVG."), ok);
  }
});

function requireAdmin(req, res, next) {
  if (!req.session.adminId) return res.status(401).json({ error: "Connexion administrateur requise." });
  next();
}
function clean(value, max = 500) {
  return String(value || "").trim().slice(0, max);
}
function validDestination(value) {
  return ["Kinshasa", "Lubumbashi"].includes(value);
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "ISAKO EXPRESS" }));

app.post("/api/inquiries", inquiryLimiter, (req, res) => {
  const name = clean(req.body.name, 120);
  const phone = clean(req.body.phone, 50);
  const email = clean(req.body.email, 160);
  const service = clean(req.body.service, 80);
  const destination = clean(req.body.destination, 40);
  const details = clean(req.body.details, 2000);
  if (!name || !phone || !service || !validDestination(destination)) {
    return res.status(400).json({ error: "Veuillez remplir les champs obligatoires et choisir Kinshasa ou Lubumbashi." });
  }
  const result = db.prepare(`INSERT INTO inquiries (name, phone, email, service, destination, details)
    VALUES (?, ?, ?, ?, ?, ?)`).run(name, phone, email || null, service, destination, details || null);
  res.status(201).json({ ok: true, id: result.lastInsertRowid, message: "Demande enregistrée. Notre équipe vous recontactera." });
});

app.get("/api/track/:code", (req, res) => {
  const code = clean(req.params.code, 40).toUpperCase();
  const shipment = db.prepare(`SELECT tracking_code, description, origin, destination, status, notes, updated_at
    FROM shipments WHERE tracking_code = ?`).get(code);
  if (!shipment) return res.status(404).json({ error: "Aucun colis trouvé avec ce code. Vérifiez le code ou contactez notre équipe." });
  res.json({ shipment });
});

app.post("/api/admin/login", authLimiter, (req, res) => {
  const email = clean(req.body.email, 160).toLowerCase();
  const password = String(req.body.password || "");
  const admin = db.prepare("SELECT id, email, password_hash FROM admins WHERE email = ?").get(email);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.status(401).json({ error: "Identifiants incorrects." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Impossible d'ouvrir la session." });
    req.session.adminId = admin.id;
    req.session.adminEmail = admin.email;
    res.json({ ok: true, email: admin.email });
  });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/me", requireAdmin, (req, res) => res.json({ email: req.session.adminEmail }));

app.get("/api/admin/dashboard", requireAdmin, (_req, res) => {
  const inquiries = db.prepare("SELECT * FROM inquiries ORDER BY id DESC LIMIT 100").all();
  const shipments = db.prepare("SELECT * FROM shipments ORDER BY id DESC LIMIT 100").all();
  const counts = {
    inquiries: db.prepare("SELECT COUNT(*) AS n FROM inquiries").get().n,
    shipments: db.prepare("SELECT COUNT(*) AS n FROM shipments").get().n,
    activeShipments: db.prepare("SELECT COUNT(*) AS n FROM shipments WHERE status NOT IN ('Livré', 'Annulé')").get().n
  };
  res.json({ inquiries, shipments, counts });
});

app.post("/api/admin/shipments", requireAdmin, (req, res) => {
  const customerName = clean(req.body.customer_name, 120);
  const customerPhone = clean(req.body.customer_phone, 50);
  const description = clean(req.body.description, 500);
  const destination = clean(req.body.destination, 40);
  const status = clean(req.body.status || "Reçu en Chine", 80);
  const notes = clean(req.body.notes, 1000);
  if (!customerName || !validDestination(destination)) {
    return res.status(400).json({ error: "Nom du client et destination valide obligatoires." });
  }
  const code = "ISX-" + crypto.randomBytes(4).toString("hex").toUpperCase();
  db.prepare(`INSERT INTO shipments (tracking_code, customer_name, customer_phone, description, destination, status, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(code, customerName, customerPhone, description, destination, status, notes);
  res.status(201).json({ ok: true, tracking_code: code });
});

app.patch("/api/admin/shipments/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = clean(req.body.status, 80);
  const notes = clean(req.body.notes, 1000);
  if (!Number.isInteger(id) || id < 1 || !status) return res.status(400).json({ error: "Données invalides." });
  const result = db.prepare("UPDATE shipments SET status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(status, notes, id);
  if (!result.changes) return res.status(404).json({ error: "Colis introuvable." });
  res.json({ ok: true });
});

app.patch("/api/admin/inquiries/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = clean(req.body.status, 50);
  if (!Number.isInteger(id) || id < 1 || !["Nouveau", "En cours", "Traité", "Archivé"].includes(status)) {
    return res.status(400).json({ error: "Statut invalide." });
  }
  const result = db.prepare("UPDATE inquiries SET status = ? WHERE id = ?").run(status, id);
  if (!result.changes) return res.status(404).json({ error: "Demande introuvable." });
  res.json({ ok: true });
});

app.post("/api/admin/logo", requireAdmin, upload.single("logo"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choisissez un fichier image valide." });
  res.json({ ok: true, logo: "/uploads/" + req.file.filename });
});

app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(400).json({ error: err.message || "Une erreur est survenue." });
});

app.listen(PORT, () => {
  console.log(`ISAKO EXPRESS est lancé sur http://localhost:${PORT}`);
  console.log("Espace administration : /admin.html");
});
