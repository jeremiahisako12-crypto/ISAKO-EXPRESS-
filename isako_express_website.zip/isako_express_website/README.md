# ISAKO EXPRESS — site web professionnel

Site responsive en français, avec une vitrine publique, un formulaire de devis, un suivi de colis et un espace d’administration protégé côté serveur.

## Fonctionnalités incluses

- Présentation premium des services : achat/commande en Chine (Pinduoduo, Taobao, 1688, Alibaba, AliExpress et SHEIN), réception et groupage, fret aérien (marchandise normale : 18,99 $/kg ; téléphone : 27 $/pièce ; ordinateur : 35 $/kg ; batterie et liquide : 26 $/kg), fret maritime normal à 500 $/CBM, livraison en RDC et conseil logistique.
- Sélection obligatoire d'une destination : **Kinshasa** ou **Lubumbashi**.
- Adresses RDC et adresse de Shanghai affichées.
- Tarifs publics indicatifs : marchandise normale 18,99 $/kg ; téléphone 27 $/pièce ; ordinateur 35 $/kg ; batterie et liquide 26 $/kg ; fret maritime normal 500 $/CBM. Les prix finaux doivent être confirmés.
- Formulaire de demande stocké dans SQLite.
- Suivi public via code unique.
- Espace administration séparé (`/admin.html`) avec connexion serveur, création de colis, modification du statut et des notes visibles au client, gestion du statut des demandes et import du logo.
- Limitation de débit sur les routes sensibles, hachage des mots de passe, session HTTP-only, Helmet et validation serveur basique.

## Lancer le site en local

Prérequis : Node.js 20 ou plus récent.

1. Décompressez le projet et ouvrez un terminal dans le dossier.
2. Installez les dépendances :

   ```bash
   npm install
   ```

3. Copiez `.env.example` vers `.env`.
4. Modifiez `SESSION_SECRET`, `ADMIN_EMAIL` et `ADMIN_PASSWORD`. Choisissez un mot de passe fort.
5. Lancez :

   ```bash
   npm start
   ```

6. Ouvrez `http://localhost:3000`. L’administration se trouve sur `http://localhost:3000/admin.html`.

L'administrateur est créé au premier démarrage si `ADMIN_PASSWORD` est défini et que l'email n'existe pas encore dans la base.

## Informations de l'entreprise intégrées

- WhatsApp : +243 894 226 845
- Kinshasa : Nyangwe 175, Lingwala, référence Huilerie
- Lubumbashi : Avenue Petit Poisson, Bel Hair, quartier Kilobelobe, référence Rond-point
- Bureau de Shanghai : 梅陇五村59号楼0304室
- Marchandise normale : 18,99 $/kg ; téléphone : 27 $/pièce ; ordinateur : 35 $/kg ; batterie et liquide : 26 $/kg ; fret maritime normal : 500 $/CBM (tarifs indicatifs à confirmer selon l’expédition)

Le monogramme « IX » est un substitut provisoire : aucun fichier de logo officiel n'était joint à cette demande. Importer un logo dans l'administration stocke le fichier, mais le logo doit encore être activé dans le HTML/CSS pour remplacer le monogramme. Pour respecter l'identité officielle, ne pas redessiner le logo d'origine.

## Important avant la mise en ligne

Ce projet est une base opérationnelle de démarrage, pas encore une installation de production complète. Avant de l'ouvrir au public :

- Déployer sur un hébergeur Node.js avec HTTPS et configurer `NODE_ENV=production`.
- Utiliser un vrai magasin de sessions persistant (la session MemoryStore par défaut ne convient pas à la production).
- Configurer sauvegardes de base de données, politique de confidentialité, consentement et durée de conservation des données.
- Ajouter un système de notification email/WhatsApp pour alerter l'équipe lors d'une nouvelle demande (aucun fournisseur externe n'est configuré dans ce starter).
- Mettre en place une procédure de changement de mot de passe et de récupération admin.
- Vérifier les règles de transport, les prix, les délais, les droits d'importation et les taxes avant de les publier.
- Ajouter le logo officiel original dans la vitrine ; il n'est pas inclus dans les fichiers reçus ici.
- Si vous avez plusieurs employés, ajouter des comptes nominatifs, rôles et journal d'audit.

L'adresse `/admin.html` n'est pas listée dans le menu client, mais son caractère « discret » ne constitue pas une sécurité : la protection réelle vient de l'authentification et des routes serveur. Ne mettez jamais de mot de passe administrateur dans le code public.
